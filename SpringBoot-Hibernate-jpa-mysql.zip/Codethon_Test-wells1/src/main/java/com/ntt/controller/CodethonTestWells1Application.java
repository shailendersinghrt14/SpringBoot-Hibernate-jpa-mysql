package com.ntt.controller;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CodethonTestWells1Application {

	public static void main(String[] args) {
		SpringApplication.run(CodethonTestWells1Application.class, args);
	}
}
