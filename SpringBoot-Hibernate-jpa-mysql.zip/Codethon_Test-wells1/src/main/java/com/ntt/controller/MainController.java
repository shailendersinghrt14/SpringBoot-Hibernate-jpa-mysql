package com.ntt.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.ntt.controller.bean.*;


@Controller
public class MainController {
	@Autowired
	UserRepo userrepo;
	//fetch the details in index view 
	@RequestMapping("/")
	public ModelAndView check() {
		ModelAndView mv =new ModelAndView("index");
		  mv.addObject("user","Hii this the login page.");
	    mv.addObject("list",userrepo.findAll());
	    return mv;
		

		
	}
	//save the data  to db
	@RequestMapping("/save" )
	ModelAndView doSave(@ModelAttribute User user) {
	ModelAndView mv =new ModelAndView("redirect:/");
  
	userrepo.save(user);
	return mv;
	}
	//delete by id from the data base
	@RequestMapping(value = "/delete/{id}", method=RequestMethod.GET)
	public ModelAndView getDeleter(@PathVariable Integer id){
		ModelAndView mv =new ModelAndView("redirect:/");
		userrepo.delete(id);
		return mv;
	
	}
	//update the details 
	@RequestMapping(value = "/edit/{id}", method=RequestMethod.GET)
	public ModelAndView getEdit(@PathVariable Integer id){
		ModelAndView mv =new ModelAndView("edit");
		mv.addObject("id",id);
		userrepo.findOne(id);
		return mv;

	}
	//updating the details 
	@RequestMapping("/saveedit")
	ModelAndView doSaveEdit(@ModelAttribute User user) {
	ModelAndView mv =new ModelAndView("redirect:/");
	mv.addObject("user",user);
	userrepo.save(user);
	return mv;
	}
}
